# Calculator

[![Build Status](https://travis-ci.com/Deepesh22/Calculator-iOS.svg?branch=master)](https://travis-ci.com/Deepesh22/Calculator-iOS)
![](https://img.shields.io/badge/platform-iOS%209.3-lightgrey.svg)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

It is a basic calculator app for iOS compatible to any layout and screen size.

### Screenshots

Portrait

![Alt text](https://github.com/Deepesh22/Calculator-iOS/blob/master/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%208%20-%202019-03-04%20at%2012.51.51.png "portrait")

Landscape

![Alt text](https://github.com/Deepesh22/Calculator-iOS/blob/master/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%208%20-%202019-03-04%20at%2012.52.59.png "landscape")

### Todos

 - Add more functionalities.
 - Change format of result(Currently always float value) . 

License
----

MIT
